package com.jieli.stream.player.ui.dialog;

import android.app.DialogFragment;
import android.content.res.Configuration;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.TextView;

import com.jieli.stream.player.R;
import com.jieli.stream.player.base.BaseDialogFragment;
import com.jieli.stream.player.util.IConstant;


public class InputPasswordDialog extends BaseDialogFragment implements IConstant {
    private EditText mContent;
    private TextView mConfirm;
    private TextView mCancel;
    private TextView mTitle;
    private final int MAX_WIFI_PWD_LENGTH = 63;
    private final int MIN_WIFI_PWD_LENGTH = 8;
    private String mTextTitle;

    public static InputPasswordDialog newInstance(String title) {
        InputPasswordDialog dialog = new InputPasswordDialog();
        Bundle args = new Bundle();
        args.putString("title", title);
        dialog.setArguments(args);
        return dialog;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(DialogFragment.STYLE_NO_TITLE, android.R.style.Theme_Translucent_NoTitleBar_Fullscreen);
        mTextTitle = getArguments().getString("title", null);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.input_password_dialog, container, false);
        mContent = (EditText) v.findViewById(R.id.et_password);
        mConfirm = (TextView) v.findViewById(R.id.tv_confirm);
        mCancel = (TextView) v.findViewById(R.id.tv_cancel);
        mTitle = (TextView) v.findViewById(R.id.tv_title);
        mConfirm.setOnClickListener(mOnClickListener);
        mCancel.setOnClickListener(mOnClickListener);
        mTitle.setText(mTextTitle);
        return v;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if(getDialog() == null || getDialog().getWindow() == null) return;
        final WindowManager.LayoutParams params = getDialog().getWindow().getAttributes();

        params.width = 100;
        params.height = 50;
        DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
            params.width = displayMetrics.heightPixels * 4 / 5;
            params.height = displayMetrics.heightPixels * 2 / 5;
        } else if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
            params.width = displayMetrics.widthPixels * 4 / 5;
            params.height = displayMetrics.widthPixels * 2 / 5;
        }
        params.gravity = Gravity.CENTER;
        getDialog().getWindow().setAttributes(params);
    }

    private final View.OnClickListener mOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (mConfirm == v) {
                commitPassword();
            } else if(mCancel == v) {
                dismiss();
            }
        }
    };

    private void commitPassword(){
        String textPWD = mContent.getText().toString().trim();

        if (TextUtils.isEmpty(textPWD)) {
            showToastLong(R.string.name_empty_error);
            textPWD = "";
        }

        if (textPWD.length() < MIN_WIFI_PWD_LENGTH || textPWD.length() > MAX_WIFI_PWD_LENGTH ){
            showToastLong(R.string.input_pwd_error);
            return;
        }

        dismiss();
        if (mOnInputCompletionListener != null){
            mOnInputCompletionListener.onCompletion(mTextTitle, textPWD);
        }
    }

    private OnInputCompletionListener mOnInputCompletionListener;
    void setOnInputCompletionListener(OnInputCompletionListener listener){
        mOnInputCompletionListener = listener;
    }
    interface OnInputCompletionListener {
        void onCompletion(String ssid, String password);
    }
}
