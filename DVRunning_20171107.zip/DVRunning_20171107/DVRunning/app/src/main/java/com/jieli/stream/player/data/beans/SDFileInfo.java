package com.jieli.stream.player.data.beans;

/**
 * @author zqjasonZhong
 * date : 2017/3/1
 */
public class SDFileInfo {
    public String Name;
    public String Path;
    public long Size;
    public boolean IsDirectory = false;
    public int FileCount = 0;
    public int FolderCount = 0;
}
