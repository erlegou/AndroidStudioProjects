package com.jieli.stream.player.data.beans;


public class SystemInfo {
    private String infoName;

    public String getInfoName() {
        return infoName;
    }

    public void setInfoName(String infoName) {
        this.infoName = infoName;
    }
}
