package com.ihunuo.touying;

import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;

import com.eleven.app.bluetoothlehelper.Peripheral;
import com.ihunuo.touying.adapters.BlueToothAdapter;

public class BluetoothActivity extends BaseActivity implements  BlueToothAdapter.Listener{

    ImageButton mbackbtn;
    ListView mListView;

    BlueToothAdapter mBluetoothdevice;

    Button mRescan;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bluetooth);
        mbackbtn = (ImageButton)findViewById(R.id.bluetooth_back);

        mRescan = (Button)findViewById(R.id.m_bluetooth_rescan);

        mListView =(ListView)findViewById(R.id.bluetooth_listview);


        mbackbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(BluetoothActivity.this, MainActivity.class);
                startActivityForResult(intent, 100);
            }
        });

        mRescan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                stratScan(true);
            }
        });


    }

    @Override
    public void onSelected(int positon) {
        connecdevice(positon);
    }

    @Override
    public void ScanCallback() {
        super.ScanCallback();

        reloaddata();
    }

    private void reloaddata()
    {
        mBluetoothdevice = new BlueToothAdapter(this,AppInscan.getmApp().getmDeviceList());
        mBluetoothdevice.setListener(this);
        mBluetoothdevice.notifyDataSetChanged();
        mListView.setAdapter(mBluetoothdevice);
    }

    @Override
    protected void onResume() {
        AppInscan.getmApp().setmNowactivit(1);
        super.onResume();

        // 启动蓝牙
        if (mBluetoothAdapter != null && !mBluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, 1);
        }


    }
    @Override
    public void ConnectCallback(Peripheral peripheral) {
        super.ConnectCallback(peripheral);
        Intent intent = new Intent(BluetoothActivity.this, MainActivity.class);
        startActivityForResult(intent, 100);


    }
}

